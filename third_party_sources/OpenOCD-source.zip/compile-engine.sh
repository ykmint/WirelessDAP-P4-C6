#!/usr/bin/env bash
set -e
export PATH=/ucrt64/bin:/usr/bin
export PKG_CONFIG=/ucrt64/bin/pkgconf.exe
cd "${1:?Pass the extracted OpenOCD source directory}"
./bootstrap nosubmodule
./configure --build=x86_64-pc-msys --host=x86_64-w64-mingw32 --enable-internal-jimtcl --disable-werror --enable-cmsis-dap-tcp --disable-cmsis-dap --disable-cmsis-dap-v2 --enable-stlink --disable-esp-remote --disable-jlink --disable-internal-libjaylink CFLAGS='-O2' LDFLAGS='-static -static-libgcc'
make -j8
make -W src/main.o src/openocd.exe LDFLAGS='-all-static -static-libgcc'
strip src/openocd.exe
